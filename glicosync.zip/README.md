# GlicoSync - Produção

Este código está pronto para ser publicado em qualquer servidor (Vercel, Netlify, VPS).

## Instruções
1. `npm install` para instalar dependências.
2. Crie um arquivo `.env` baseado no `.env.example` e insira sua API_KEY.
3. `npm run build` para gerar a pasta `dist`.
4. Publique o conteúdo de `dist` no seu servidor.